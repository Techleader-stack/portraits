Photographer Portfolio - Setup Instructions
------------------------------------------

Files included:
- index.html, about.html, gallery.html, contact.html
- styles.css, script.js
- images.php, contact.php
- README.md

What's required:
- PHP 7+ (for images.php and contact.php) OR you can host static HTML and omit backend functionality.
- Create two folders in the project root:
  - images/   (place up to 8 photos here; e.g. IMG_001.jpg)
  - data/     (PHP will write contact messages here)

Install & run locally:
1. Copy files into a folder (e.g., mysite).
2. Create folders:
   mkdir images data
   chmod 755 images data   (or 775/777 on local dev if required)
3. Add your photos to images/ (jpg/png/gif/webp). The gallery shows up to 8 images sorted newest-first.
4. Start PHP built-in server (from project folder):
   php -S localhost:8000
5. Open http://localhost:8000/index.html

Notes:
- The gallery HTML files are plain HTML pages and the images are loaded dynamically via images.php (so the HTML stays static).
- Contact form posts to contact.php which saves messages to data/messages.txt and returns JSON for the frontend.
- For production, secure the endpoints, add spam protection (CAPTCHA), and configure proper email / database storage if needed.

If you'd like, I can:
- add an admin upload page (PHP) to upload images into the images/ folder,
- create placeholder images so the gallery is populated immediately,
- or adapt the site to use a database for messages and user accounts.

Tell me which addition you'd like and I will prepare it next.