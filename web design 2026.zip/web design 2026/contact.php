<?php
// contact.php
// Accepts POST from contact.html and appends sanitized message to data/messages.txt
// Returns JSON { success: "..."} or { errors: ["...", ...] }

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['errors' => ['Method not allowed']]);
    exit;
}

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');
$datePref = trim($_POST['date'] ?? '');

$errors = [];
if ($name === '') $errors[] = 'Name is required.';
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
if ($message === '') $errors[] = 'Message is required.';

if ($errors) {
    echo json_encode(['errors' => $errors]);
    exit;
}

// sanitize for storage
$safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
$safeEmail = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
$safeMessage = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
$safeDate = $datePref ? htmlspecialchars($datePref, ENT_QUOTES, 'UTF-8') : '';

$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) @mkdir($dataDir, 0755, true);

$logfile = $dataDir . '/messages.txt';
$entry = "[".date('Y-m-d H:i:s')."] {$safeName} <{$safeEmail}>";
if ($safeDate) $entry .= " (preferred date: {$safeDate})";
$entry .= ":\n{$safeMessage}\n\n";

if (file_put_contents($logfile, $entry, FILE_APPEND | LOCK_EX) === false) {
    http_response_code(500);
    echo json_encode(['errors' => ['Could not save message.']]);
    exit;
}

// Optionally send an email — commented out by default
// @mail('you@domain.com', 'Website contact: ' . $safeName, $safeMessage, "From: {$safeEmail}");

echo json_encode(['success' => 'Thanks! Your message has been received.']);