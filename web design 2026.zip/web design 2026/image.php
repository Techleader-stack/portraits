<?php
// images.php
// Returns up to 8 image URLs (newest first) from the images/ folder as JSON.
// Place your photos in the "images/" folder (jpg, jpeg, png, gif, webp).
header('Content-Type: application/json; charset=utf-8');

$dir = __DIR__ . '/images';
$baseUrl = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
if ($baseUrl === '' || $baseUrl === '.') $baseUrl = '';
$prefix = $baseUrl . '/images/';

$urls = [];
if (is_dir($dir)) {
    $files = glob($dir . '/*.{jpg,jpeg,png,gif,webp,JPG,JPEG,PNG,GIF,WEBP}', GLOB_BRACE);
    usort($files, function($a, $b){ return filemtime($b) - filemtime($a); });
    $files = array_slice($files, 0, 8);
    foreach ($files as $f) {
        $urls[] = $prefix . basename($f);
    }
}
// Return array (may be empty)
echo json_encode($urls, JSON_UNESCAPED_SLASHES);