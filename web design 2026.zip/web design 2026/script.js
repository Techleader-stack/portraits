// gallery loading, lightbox, and contact form handling
document.addEventListener('DOMContentLoaded', function(){
  // Lightbox
  const gallery = document.getElementById('gallery');
  const previewGrid = document.getElementById('previewGrid');
  const lightbox = document.getElementById('lightbox');
  const lbImage = document.getElementById('lbImage');
  const lbClose = document.getElementById('lbClose');

  function openLightbox(src, alt){
    if (!lightbox) return;
    lbImage.src = src;
    lbImage.alt = alt || '';
    lightbox.style.display = 'flex';
    lightbox.setAttribute('aria-hidden','false');
  }
  function closeLightbox(){
    if (!lightbox) return;
    lightbox.style.display = 'none';
    lightbox.setAttribute('aria-hidden','true');
    lbImage.src = '';
  }
  if (lbClose) lbClose.addEventListener('click', closeLightbox);
  if (lightbox) lightbox.addEventListener('click', function(e){ if (e.target === lightbox) closeLightbox(); });

  // Fetch up to 8 images from images.php and populate gallery + preview
  fetch('images.php')
    .then(r => r.json())
    .then(images => {
      // gallery.html: populate full grid of 8 slots
      if (gallery) {
        gallery.innerHTML = '';
        for (let i = 0; i < 8; i++){
          if (images[i]) {
            const url = images[i];
            const fig = document.createElement('figure');
            fig.className = 'thumb';
            fig.innerHTML = `<img src="${url}" alt="Portfolio image ${i+1}" loading="lazy" data-full="${url}"><figcaption>Image ${i+1}</figcaption>`;
            gallery.appendChild(fig);
          } else {
            const ph = document.createElement('figure');
            ph.className = 'thumb placeholder';
            ph.innerHTML = `<div class="ph">Empty Slot</div><figcaption>Slot ${i+1}</figcaption>`;
            gallery.appendChild(ph);
          }
        }
      }
      // index.html preview: top 3 images
      if (previewGrid) {
        previewGrid.innerHTML = '';
        for (let i = 0; i < 3; i++){
          if (images[i]) {
            const url = images[i];
            const fig = document.createElement('figure');
            fig.className = 'thumb';
            fig.innerHTML = `<img src="${url}" alt="Preview ${i+1}" loading="lazy" data-full="${url}">`;
            previewGrid.appendChild(fig);
          } else {
            const ph = document.createElement('figure');
            ph.className = 'thumb placeholder';
            ph.innerHTML = `<div class="ph">Empty</div>`;
            previewGrid.appendChild(ph);
          }
        }
      }

      // delegate click to open lightbox
      [gallery, previewGrid].forEach(container => {
        if (!container) return;
        container.addEventListener('click', function(e){
          const img = e.target.closest('img');
          if (!img) return;
          const full = img.dataset.full || img.src;
          openLightbox(full, img.alt || '');
        });
      });
    })
    .catch(err => {
      // keep placeholders if images cannot be loaded
      console.warn('Could not load gallery images', err);
    });

  // Contact form: client validation and AJAX submit to contact.php
  const contactForm = document.getElementById('contactForm');
  const formMessage = document.getElementById('formMessage');
  if (contactForm){
    contactForm.addEventListener('submit', function(e){
      e.preventDefault();
      const data = new FormData(contactForm);
      const name = (data.get('name') || '').trim();
      const email = (data.get('email') || '').trim();
      const message = (data.get('message') || '').trim();
      const errs = [];
      if (!name) errs.push('Name is required.');
      if (!email || !/^\S+@\S+\.\S+$/.test(email)) errs.push('A valid email is required.');
      if (!message) errs.push('Message is required.');
      if (errs.length){
        showFormMessage(errs.join(' '), 'error');
        return;
      }
      // send via fetch
      fetch(contactForm.action, {
        method: 'POST',
        body: data,
        headers: { 'Accept': 'application/json' }
      })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          showFormMessage(res.success, 'success');
          contactForm.reset();
        } else if (res.errors) {
          showFormMessage(res.errors.join(' '), 'error');
        } else {
          showFormMessage('Unknown error. Try again later.', 'error');
        }
      })
      .catch(() => showFormMessage('Could not send message. Try later.', 'error'));
    });
  }

  function showFormMessage(text, type){
    if (!formMessage) {
      alert(text);
      return;
    }
    formMessage.style.display = 'block';
    formMessage.textContent = text;
    formMessage.className = 'alert ' + (type === 'success' ? 'alert-success' : 'alert-error');
    setTimeout(()=>{ if (formMessage) formMessage.style.display = 'none'; }, 8000);
  }
});